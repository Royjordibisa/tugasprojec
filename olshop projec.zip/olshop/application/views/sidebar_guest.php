<h3>Member</h3>
	<ul class="list">
		<li>
			<a href="<?php echo base_url(); ?>index.php/keranjang">Keranjang</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>index.php/member/register">Register</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>index.php/member/login">Login</a>
		</li>
	</ul>
