<div class="clear"></div>
<div class="grid_12">
<?php echo auto_typography($konten); ?>
</div>
<div class="clear"></div>